@extends('layout')
@section('content')
    <h1>Welcome to Laravel 5.8</h1>
@endsection
