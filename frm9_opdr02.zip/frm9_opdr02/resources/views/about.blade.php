@extends('layout')
@section('title', 'About Us')
@section('content')
<h1>About Us</h1>

<p>Company bio here</p>
@endsection
