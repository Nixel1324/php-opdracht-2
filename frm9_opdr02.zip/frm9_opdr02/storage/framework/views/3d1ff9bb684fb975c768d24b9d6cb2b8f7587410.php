<ul class="nav py-3">
    <li class="nav-link"><a class="nav-link" href="/">Home</a></li>
    <li class="nav-link"><a class="nav-link" href="about">About Us</a></li>
    <li class="nav-link"><a class="nav-link" href="contact">Contact Us</a></li>
    <li class="nav-link"><a class="nav-link" href="customers">Customers</a></li>
</ul>
<?php /**PATH C:\xampp\htdocs\frm9_opdr02\resources\views/nav.blade.php ENDPATH**/ ?>